/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.bonn.ooka.controller;

/**
 *
 * @author alex
 */
public class Pages {
    
    public static final String PARTICIPENT_INDEX_PAGE = "participantMask";
    public static final String PARTICIPENT_RESULT_PAGE = "participantResult";
    public static final String PARTICIPENT_CONFIRM_PAGE = "participantConfirm";
    
    public static final String ORGANIZER_INDEX_PAGE = "organizerMask";
    public static final String ORGANIZER_RESULT_PAGE = "organizerResult";
    public static final String ORGANIZER_CONFIRM_PAGE = "organizerConfirm";
    public static final String ORGANIZER_EDIT_PAGE = "organizerEdit";
    
}
